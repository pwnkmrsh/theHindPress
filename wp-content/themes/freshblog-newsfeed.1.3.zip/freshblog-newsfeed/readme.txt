# Freshblog Newsfeed

Contributors: themeeverest
Requires at least: 4.0  
Tested up to: 6.1
Stable tag: 1.0
Version: 1.0
License: GNU General Public License v3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
Tags: theme-options, threaded-comments, translation-ready, sticky-post, footer-widgets, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-image-header, featured-images, flexible-header, right-sidebar, one-column, two-columns, three-columns, buddypress, full-width-template, e-commerce, blog, news

Freshblog Newsfeed: A clean & free WordPress theme for bloggers, writers, newspapers, and publishers. It offers a colorful, minimal magazine design with sidebars and optional dark mode. Compatible with Brizy, Elementor Website Builder, and Divi Builder, customization is a easy. Ideal for AdSense advertisement, affiliate marketing, and sidebar banner ads, it's perfect for any niche, including business, lifestyle, fashion, and travel. Mobile friendly and responsive, it has fast loading times and SEO optimization for better search engine rankings. With WooCommerce support you can transform your site into an ecommerce platform. It's translation ready, supports schema markup for enhanced visibility, and provides comprehensive review writing and publishing tools. Freshblog Newsfeed: simple, yet powerful for any blogging need. 

## Description

Freshblog Newsfeed: A clean & free WordPress theme for bloggers, writers, newspapers, and publishers. It offers a colorful, minimal magazine design with sidebars and optional dark mode. Compatible with Brizy, Elementor Website Builder, and Divi Builder, customization is a easy. Ideal for AdSense advertisement, affiliate marketing, and sidebar banner ads, it's perfect for any niche, including business, lifestyle, fashion, and travel. Mobile friendly and responsive, it has fast loading times and SEO optimization for better search engine rankings. With WooCommerce support you can transform your site into an ecommerce platform. It's translation ready, supports schema markup for enhanced visibility, and provides comprehensive review writing and publishing tools. Freshblog Newsfeed: simple, yet powerful for any blogging need.


## Copyright
Freshblog Newsfeed WordPress Theme, Copyright 2022 themeeverest
Freshblog Newsfeed is distributed under the terms of the GNU GPL

Freshblog Newsfeed bundles the following third-party resources:


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

______

Image license:
https://pxhere.com/en/photo/850583
https://pxhere.com/en/photo/1571887
https://pxhere.com/en/photo/893407
https://pxhere.com/en/photo/547984

* Based on Underscores (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* License: GNU General Public License v2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html
* Copyright: Automattic http://underscores.me/

* normalize.css http://necolas.github.io/normalize.css/, (C) 
* 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

* Font Awesome - http://fortawesome.github.io/Font-Awesome/
* Font License
* Applies to all desktop and webfont files in the following directory: /fonts/.
* License: SIL OFL 1.1
* URL: http://scripts.sil.org/OFL
* Code License
* Applies to all CSS and LESS files in the following directories: /css/ and /less/.
* License: MIT License
* URL: http://opensource.org/licenses/mit-license.html
* Documentation License
* Applies to all Font Awesome project files that are not a part of the Font or Code licenses.
* License: CC BY 3.0
* URL: http://creativecommons.org/licenses/by/3.0/

* html5shiv - http://code.google.com/p/html5shiv/ License Under MIT (http://opensource.org/licenses/MIT)

* Copyright and License for Upsell button by Justin Tadlock - 2016 © Justin Tadlock.
* Link: https://github.com/justintadlock/trt-customizer-pro
* License: GPL Friendly
* License URI: https://github.com/justintadlock/trt-customizer-pro/blob/master/license.md

* We use TGM Plugin Activation (TGMPA) http://tgmpluginactivation.com/ 
*  TGM Plugin Activation
*The TGM Plugin Activation library is licensed under the GPL-2.0 or later license. https://opensource.org/licenses/GPL-2.0
* [![GitHub license](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/TGMPA/TGM-Plugin-Activation/develop/LICENSE.md)
* [![Build Status](https://travis-ci.org/TGMPA/TGM-Plugin-Activation.svg?branch=develop)](https://travis-ci.org/TGMPA/TGM-Plugin-Activation)
* [![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/TGMPA/TGM-Plugin-Activation/badges/quality-score.png?b=develop)](https://scrutinizer-ci.com/g/TGMPA/TGM-Plugin-Activation/?branch=develop)

* Webfont Loader
	* URL: https://github.com/WPTT/webfont-loader
	* MIT License: https://github.com/WPTT/webfont-loader?tab=MIT-1-ov-file#readme
	* Contributor list: https://github.com/WPTT/webfont-loader/graphs/contributors