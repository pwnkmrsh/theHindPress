<?php

add_action('xews_lite_top_top_header','blog_news_header_ticker', 10);
function blog_news_header_ticker(){
    ?>
    <div class="top-header xews-header-container">
        <div class="container">
            <div class="top-header-xews-wrapper top-header-elem-wrap header-elements-wrap cww-flex">
                <?php
                    xews_news_ticker_module();
                    do_action('blog_news_top_left_header');
                 ?>
            </div>
        </div>
    </div>
    <?php 
}

function xews_news_ticker_module(){ 
    wp_print_styles( array( 'slick' ) );
    wp_print_scripts( array( 'slick' ) );

    $defaults                            = blog_news_customizer_defaults();
    $blog_news_ticker_label              = get_theme_mod('blog_news_ticker_label',$defaults['blog_news_ticker_label']);
    $blog_news_ticker_label_layout       = get_theme_mod('blog_news_ticker_label_layout', $defaults['blog_news_ticker_label_layout']);
    $blog_news_ticker_label_icon_show    = get_theme_mod('blog_news_ticker_label_icon_show', $defaults['blog_news_ticker_label_icon_show']);
    
    ?>

    <div class="xews-ticker-wrapper">
        <div class="inner-wrapper cww-flex">
        <div class="ticker-label <?php echo esc_attr($blog_news_ticker_label_layout)?>">
            <?php if($blog_news_ticker_label_icon_show){ ?>
            <span class="label-icon"><i class="fas fa-bolt"></i></span>
            <?php } ?>
            <span><?php echo esc_html($blog_news_ticker_label); ?></span>
        </div>
        <?php echo xews_news_ticker_latest_posts(); ?>
        </div>
    </div>

<?php }

/**
 * Ticker content controller
 */
function xews_ticker_content_controller($ticker_args){

    $ticker_query = new WP_Query( $ticker_args );
    if( $ticker_query->have_posts() ):
        echo '<ul class="xews-news-ticker-content" >';
        while( $ticker_query->have_posts() ) {
            $ticker_query->the_post();  
            ?>
            <li>
                <?php  xews_news_ticker_date(); ?>
                <a href="<?php the_permalink(); ?>" >
                    <?php the_title(); ?>
                </a>
            </li>
            <?php 
        }
        wp_reset_postdata();
        echo '</ul>';
    endif;
}



/**
 * Display from latest posts
 */
function xews_news_ticker_latest_posts(){

    $defaults                        = blog_news_customizer_defaults();
    $blog_news_ticker_post_no        = get_theme_mod('blog_news_ticker_post_no',$defaults['blog_news_ticker_post_no']);
    $blog_news_ticker_post_offset    = get_theme_mod('blog_news_ticker_post_offset', $defaults['blog_news_ticker_post_offset']);
    

    $ticker_args = array(
        'post_type'             => 'post',
        'posts_per_page'        => absint($blog_news_ticker_post_no),
        'offset'                => absint($blog_news_ticker_post_offset),
        'ignore_sticky_posts'   => 1
    ); 
 
    echo xews_ticker_content_controller($ticker_args);
}



function xews_news_ticker_date(){
    $defaults       = blog_news_customizer_defaults();

    $blog_news_ticker_date_show = get_theme_mod('blog_news_ticker_date_show', $defaults['blog_news_ticker_date_show']);
    
    if( $blog_news_ticker_date_show ){

        $news_month     = get_the_date('m');
        $news_day       = get_the_date('d');
        ?>

        <span class="xews-news-ticker-date" title="<?php esc_attr_e( 'Published on:', 'blog-news' ); ?> <?php echo get_the_date(); ?>">
            <span class="xews-news-ticker-date-month"><?php echo esc_html( $news_month ); ?></span>
            <span class="xews-news-ticker-date-sep">/</span>
            <span class="xews-news-ticker-date-day"><?php echo esc_html( $news_day ); ?></span>
            <span>:</span>
        </span>
    <?php
    }
}



/**
 * Default customizer settings value
 */
function blog_news_customizer_defaults(){
    $defaults = array();
    $defaults['blog_news_ticker_label_layout']              = 'layout-two';
    $defaults['blog_news_ticker_label']                     = esc_html__('Live Updates','blog-news');
    $defaults['blog_news_ticker_date_show']                 = 0;
    $defaults['blog_news_ticker_label_icon_show']           = true;
    $defaults['blog_news_ticker_post_no']                   = 5;
    $defaults['blog_news_ticker_post_offset']               = 0;



    return $defaults;
}