<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
if ( !function_exists( 'blog_news_locale_css' ) ):
    function blog_news_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'blog_news_locale_css' );


if ( !function_exists( 'blog_news_add_scripts' ) ):
    function blog_news_add_scripts() {
        wp_enqueue_style( 'blog-news-parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array( 'xews-dark-mode' ) );
        wp_enqueue_style( 'slick', trailingslashit( get_stylesheet_directory_uri() ) . '/assets/slick/slick.css', array() );

        wp_enqueue_script( 'slick', trailingslashit( get_stylesheet_directory_uri() ) . '/assets/slick/slick.min.js', array('jquery'), XEWS_LITE_VERSION, true );
        wp_enqueue_script( 'blog-news', trailingslashit( get_stylesheet_directory_uri() ) . '/assets/js/scripts.js', array('jquery'), XEWS_LITE_VERSION, true );
    }
endif;
add_action( 'wp_enqueue_scripts', 'blog_news_add_scripts', 10 );


require get_stylesheet_directory() . '/customizer-ticker.php';
require get_stylesheet_directory() . '/functions-init.php';



add_action( 'init', 'blog_news_init');
function blog_news_init(){
    remove_action('xews_lite_top_header','xews_lite_site_branding', 10 );
    remove_action('xews_lite_top_header','xews_lite_top_left_header', 20 );

    add_action('xews_lite_bottom_header','xews_lite_site_branding', 5 );
    add_action('blog_news_top_left_header','xews_lite_top_left_header', 20);
}

/**
 * Override parent default setting values
 */
add_filter('xews_lite_default_theme_options','blog_news_parent_defaults');
function blog_news_parent_defaults(){

    $defaults = array();
        $theme_color = '#f70776';

        $defaults['xews_lite_theme_color']                   = $theme_color;
      
    
        $defaults['xews_lite_search_icon_color']             = '#fff';
        $defaults['xews_lite_date_display_enable']           = true;
        $defaults['xews_lite_darkmode_enable']               = true;
        $defaults['xews_lite_search_display_enable']         = true;
        $defaults['xews_lite_date_display_type']             = 'date-only';
        $defaults['xews_lite_date_text_color']               = '#fff';
        $defaults['xews_lite_nav_font_size']                 = 16;
        $defaults['xews_lite_nav_text_transform']            = 'none';
        $defaults['xews_lite_nav_hover_effect']              = 'none';
        $defaults['xews_lite_nav_bg_color']                  = '#333';
        $defaults['xews_lite_nav_underline_color']           = $theme_color;


        $defaults['xews_lite_title_tagline_color']           = '#333';

        
        $defaults['xews_lite_container_width']               = 1200;
        $defaults['xews_lite_related_posts_title']           = esc_html__('Related Posts','blog-news');
        $defaults['xews_lite_related_post_type']             = 'cat';
        $defaults['xews_lite_related_post_count']            = 3;
        $defaults['xews_lite_related_post_offset']           = 0;
        $defaults['xews_lite_related_post_excerpts']         = 200;


        $defaults['xews_lite_inner_single_sidebar']          = 'sidebar-right';
        $defaults['xews_lite_inner_blog_sidebar']            = 'sidebar-right';
        $defaults['xews_lite_post_sidebar_area']             = 'sidebar-1';
        $defaults['xews_lite_post_sidebar_sticky_enable']    = true;
        $defaults['xews_lite_blog_sidebar_sticky_enable']    = true;
        $defaults['xews_lite_inner_blog_excerpt']            = 350;
        $defaults['xews_lite_post_readmore_enable']          = false;
        
        $defaults['xews_lite_blog_sidebar_area']             = 'sidebar-1';
        

        $defaults['xews_lite_nav_color']                     = '#333';

        
        return $defaults;

}
